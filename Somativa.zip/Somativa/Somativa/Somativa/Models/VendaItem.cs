﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class VendaItem
    {
        public Guid VendaItemId { get; set; }
        [DisplayName("Nota Fiscal")]
        [Required(ErrorMessage = "A Nota Fiscal deve ser inserida")]
        public Guid VendaId { get; set; }
        public Venda? Venda { get; set; }
        [DisplayName("Produto")]
        [Required(ErrorMessage = "O produto deve ser inserida")]
        public Guid ProdutoId { get; set; }
        public Produto? Produto { get; set; }
        [Required(ErrorMessage = "A Quantidade deve ser inserida")]
        public int Quantidade { get; set; }
        [Required(ErrorMessage = "O preço Unitário deve ser inserido")]
        public decimal Unitario { get; set; }
    }
}
