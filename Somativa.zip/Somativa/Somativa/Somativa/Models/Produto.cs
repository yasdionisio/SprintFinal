﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Produto
    {
        public Guid ProdutoId { get; set; }

        [Required(ErrorMessage = "O NOME deve ser inserido")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O estoque deve ser inserido")]
        public int Estoque { get; set; }

        [Required(ErrorMessage = "O preço deve ser inserido")]
        [DisplayName("Preço")]
        public decimal Preco { get; set; }

        [Required(ErrorMessage = "A categoria deve ser inserido")]
        [DisplayName("Categoria")]
        public Guid CategoriaId { get; set; }
        public Categoria? Categoria { get; set; }
        [DisplayName("Fornecedor")]
        public Guid FornecedorId { get; set; }
        public Fornecedor? Fornecedor { get; set; }
        public string? Imagem { get; set; }
    }
}
