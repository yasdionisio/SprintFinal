﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Compra
    {
        public Guid CompraId { get; set; }

        [DisplayName("Nota Fiscal")]
        [Required(ErrorMessage = "A nota fiscal deve ser inserido")]
        public int Nota { get; set; }

        [DisplayName("Data e hora")]
        [Required(ErrorMessage = "A data deve ser inserido")]
        public DateTime DataHora { get; set; }
        public IEnumerable<CompraItem>? CompraItems { get; set; }
    }
}
