﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Venda
    {
        public Guid VendaId { get; set; }

        [Required(ErrorMessage = "A nota fiscal deve ser inserido")]
        [DisplayName("Nota Fiscal")]
        public int Nota { get; set; }
        [DisplayName("Cliente")]
        public Guid ClienteId { get; set; }
        public Cliente? Cliente { get; set; }

        [Required(ErrorMessage = "A data e a hora devem ser inseridas")]
        [DisplayName("Data e hora")]
        public DateTime DataHora { get; set; }
        public IEnumerable<VendaItem>? VendaItems { get; set; }
    }
}
