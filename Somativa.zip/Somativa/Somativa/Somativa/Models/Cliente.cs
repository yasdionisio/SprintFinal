﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Somativa.Models
{
    public class Cliente
    {
        public Guid ClienteId { get; set; }

        [Required(ErrorMessage = "O nome deve ser inserido")]
        public string Nome { get; set; }

        [DisplayName("Endereço")]
        [Required(ErrorMessage = "O endereço deve ser inserido")]
        public string Endereco { get; set; }

        [Required(ErrorMessage = "O telefone deve ser inserido")]
        public string Telefone { get; set; }

        [DisplayName("CPF")]
        [Required(ErrorMessage = "O CPF deve ser inserido")]
        public string Cpf { get; set; }

        [DisplayName("E-mail")]
        [Required(ErrorMessage = "O e-mail deve ser inserido")]
        public string Email { get; set; }

        [Required(ErrorMessage = "A data de nascimento deve ser inserido")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime Nascimento { get; set; }
        public IEnumerable<Venda>? Venda { get; set; }
    }
}
